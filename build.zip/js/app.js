var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
// @ts-ignore
if (window.Vue)
    Vue.default = Vue;
var app = __assign(__assign({}, initApp), { exec: function (key, ext) {
        if (!ext)
            ext = "";
        return app.get("$files." + key).then(function (code) {
            if (code)
                eval(code + ext);
        });
    },
    loadjs: function (url) {
        var key = "$script." + url;
        return app.get(key).then(function (code) {
            if (code)
                eval(code);
            else
                return axios.get(url).then(function (x) {
                    eval(x.data);
                    return app.set(key, x.data);
                });
        });
    },
    loadcss: function (url) {
        return new Promise(function (resolve, reject) {
            var link = document.createElement("link");
            link.type = "text/css";
            link.rel = "stylesheet";
            link.href = url;
            link.onload = resolve;
            link.onerror = reject;
            document.head.appendChild(link);
        });
    },
    set: function (key, data) {
        return new Promise(function (resolve, reject) {
            var _a;
            chrome.storage.local.set((_a = {}, _a[key] = data, _a), resolve);
        });
    },
    get: function (key) {
        return new Promise(function (resolve, reject) {
            chrome.storage.local.get(key, function (v) {
                resolve(v[key]);
            });
        });
    },
    update: function () {
        return app.get("$app.files").then(function (x) {
            if (x)
                for (var k in x) {
                    app.files[k] = x[k];
                }
            return axios.get(app.baseURL + "/app.json").then(function (x) {
                var cur = x.data;
                if (cur.appname != app.appname)
                    return app;
                cur.changes = {};
                var all = [];
                var _loop_1 = function (key) {
                    if (cur.files[key] != app.files[key]) {
                        all.push(axios
                            .get(app.baseURL + "/js/" + key + ".js")
                            .then(function (js) { return app.set("$files." + key, js.data); })
                            .then(function (x) {
                            cur.changes[key] = true;
                            app.files[key] = cur.files[key];
                        })
                            .catch(function () { return 0; }));
                    }
                };
                for (var key in cur.files) {
                    _loop_1(key);
                }
                if (!all.length)
                    return cur;
                return Promise.all(all)
                    .then(function () { return app.set("$app.files", app.files); })
                    .then(function () { return cur; });
            }, function () { return app; });
        });
    }, deviceready: void 0 });
app.deviceready = app.update();
