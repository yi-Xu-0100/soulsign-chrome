app.update().then(function(){app.exec("background")});
if(app.dev) {
	setInterval(function() {
		app.update().then(function(cur) {
			if(cur.version!=app.version) 
				chrome.runtime.reload()
			else if(cur.changes&&cur.changes.background) location.reload()
		})
	}, 1e3);
}